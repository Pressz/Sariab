package com.gordarg.sariab.Presenters;

public interface IDetailsPresenter {
    void doDownload(String Id);
}
