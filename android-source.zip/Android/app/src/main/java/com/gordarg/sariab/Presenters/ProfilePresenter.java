package com.gordarg.sariab.Presenters;

import com.gordarg.sariab.Models.User;

public class ProfilePresenter implements IProfilePresenter {
    @Override
    public void doSubmitData(User user) {
        // TODO
    }

    @Override
    public void doBindData() {
        // TODO
    }
}
