package com.gordarg.sariab.Presenters;

public interface IRexaBasePresenter {
    void doNetworkTest();
}
