package com.gordarg.sariab.Configuration;

public interface IConfiguration {
    public boolean equalsName(String otherName);
    public String toString();
    public int toInt();
}
