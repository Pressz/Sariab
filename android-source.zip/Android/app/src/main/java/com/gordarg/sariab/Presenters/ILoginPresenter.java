package com.gordarg.sariab.Presenters;

public interface ILoginPresenter {
    void doLogin(String username, String password);
}
