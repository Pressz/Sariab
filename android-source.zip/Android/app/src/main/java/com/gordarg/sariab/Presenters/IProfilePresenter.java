package com.gordarg.sariab.Presenters;

import com.gordarg.sariab.Models.User;

public interface IProfilePresenter {
    void doSubmitData(User user);
    void doBindData();
}
