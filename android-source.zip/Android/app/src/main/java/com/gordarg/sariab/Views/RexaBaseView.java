package com.gordarg.sariab.Views;

public interface RexaBaseView {
    void onNetworkTestFailure(String message);
    void onNetworkTestSuccess(String message);
}
